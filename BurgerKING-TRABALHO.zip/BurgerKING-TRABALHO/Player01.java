import greenfoot.*; 

public class Player01 extends Actor
{
    int pontos1 = 0;

    public void act()
    {
        if (Greenfoot.isKeyDown("w")) {
            setLocation(getX(), getY() - 5);
        }

        if (Greenfoot.isKeyDown("s")) {
            setLocation(getX(), getY() + 5);
        }

        if (Greenfoot.isKeyDown("a")) {
            setLocation(getX() - 5, getY());
        }

        if (Greenfoot.isKeyDown("d")) {
            setLocation(getX() + 5, getY());
        }

        Rodeio_direita rodeio = (Rodeio_direita)getOneIntersectingObject(Rodeio_direita.class);

        if (rodeio != null)
        {
            getWorld().removeObject(rodeio);

            pontos1++;

            if (pontos1 >= 3)
            {
                Greenfoot.setWorld(new vitoria_01());
            }
        }

        getWorld().showText("PLAYER-1: " + pontos1, 150, 50);
    }
}