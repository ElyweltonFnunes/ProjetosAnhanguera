import greenfoot.*;  

public class Whopper_esquerda extends Actor
{
    public void act()
    {
        mover();
        
        // Verifica se está tocando em outro objeto
        if (isTouching(Player02.class)) {
            getWorld().removeObject(this); // Remove o Whopper_esquerda
        }
    }
    
    public void mover()
    {
        move(5);  // Move o objeto para a direita
        
        // Se atingir a borda direita, reposiciona na esquerda com um valor aleatório para Y
        if(getX() >= getWorld().getWidth() - 1){
            setLocation(1, Greenfoot.getRandomNumber(600)); 
        }
        
        // Se atingir a borda inferior, remove o objeto
        if(getY() >= getWorld().getHeight() - 1) {
            getWorld().removeObject(this);
        }
    }
}