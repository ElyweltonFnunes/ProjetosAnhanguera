import greenfoot.*; 

public class Player02 extends Actor
{
    int pontos1 = 0;

    public void act()
    {
        if (Greenfoot.isKeyDown("up")) {
            setLocation(getX(), getY() - 5);
        }

        if (Greenfoot.isKeyDown("down")) {
            setLocation(getX(), getY() + 5);
        }

        if (Greenfoot.isKeyDown("left")) {
            setLocation(getX() - 5, getY());
        }

        if (Greenfoot.isKeyDown("right")) {
            setLocation(getX() + 5, getY());
        }

        Whopper_esquerda Whopper = (Whopper_esquerda)getOneIntersectingObject(Whopper_esquerda.class);

        if (Whopper != null)
        {
            getWorld().removeObject(Whopper);

            pontos1++;

            if (pontos1 >= 3)
            {
                Greenfoot.setWorld(new vitoria_01());
            }
        }

        getWorld().showText("PLAYER-2: " + pontos1, 1050, 50);
    }
}