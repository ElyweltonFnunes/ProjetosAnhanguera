import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ponto here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ponto extends Actor
{
    /**
     * Act - do whatever the ponto wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        if(Greenfoot.isKeyDown("space")){
        Greenfoot.setWorld(new MyWorld());
        }
    }
}