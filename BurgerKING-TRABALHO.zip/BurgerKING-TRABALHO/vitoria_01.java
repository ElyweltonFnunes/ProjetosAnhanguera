import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class vitoria_01 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class vitoria_01 extends World
{

    /**
     * Constructor for objects of class vitoria_01.
     * 
     */
    public vitoria_01()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1200, 600, 1); 
        prepare();
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        ponto ponto = new ponto();
        addObject(ponto,2,6);
    }
}
