import greenfoot.*; 
public class MyWorld extends World
{
    public MyWorld()
    {    
        super(1200, 600, 1); 
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Rodeio_direita rodeio = new Rodeio_direita();
        addObject(rodeio,1048,90);
        Rodeio_direita rodeio2 = new Rodeio_direita();
        addObject(rodeio2,896,289);
        Rodeio_direita rodeio3 = new Rodeio_direita();
        addObject(rodeio3,940,451);
        Rodeio_direita rodeio4 = new Rodeio_direita();
        addObject(rodeio4,1057,512);
        rodeio3.setLocation(963,460);
        rodeio3.setLocation(963,460);
        removeObject(rodeio3);
        Player01 player01 = new Player01();
        addObject(player01,141,271);
        Player02 player02 = new Player02();
        addObject(player02,1081,266);
        player02.setLocation(1058,243);
        removeObject(player02);
        addObject(player02,1058,277);
        Whopper_esquerda whopper_esquerda = new Whopper_esquerda();
        addObject(whopper_esquerda,148,90);
        Whopper_esquerda whopper_esquerda2 = new Whopper_esquerda();
        addObject(whopper_esquerda2,305,291);
        whopper_esquerda2.setLocation(195,456);
        Whopper_esquerda whopper_esquerda3 = new Whopper_esquerda();
        addObject(whopper_esquerda3,195,456);
        removeObject(whopper_esquerda3);
        removeObject(whopper_esquerda2);
        addObject(whopper_esquerda3,302,296);
        Whopper_esquerda whopper_esquerda4 = new Whopper_esquerda();
        addObject(whopper_esquerda4,144,501);
    }
    
    public void act()
    {
        if (Greenfoot.getRandomNumber(100) < 1) {
            addObject(new Whopper_esquerda(),Greenfoot.getRandomNumber(getWidth()), 0);
        }
        
        if (Greenfoot.getRandomNumber(100) < 1) {
            addObject(new Rodeio_direita(),Greenfoot.getRandomNumber(getWidth()), 0);
        }  
        
    }
}
        
        
        
        
        
        
        
    
