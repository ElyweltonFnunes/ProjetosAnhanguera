import greenfoot.*;  
public class Rodeio_direita extends Actor
{
   public void act()
    {
        // Chamando um metodo
        mover();
        
        // Verifica se está tocando em outro objeto
        if (isTouching(Player01.class)) {
            getWorld().removeObject(this); // Remove o Whopper_esquerda
        }
        
    }
    
    public void mover()
    {
    move(-5);  // move o objeto para a esquerda
    if(getX() <= 0) {  // verifica se chegou na borda esquerda
        setLocation(getWorld().getWidth() - 1, Greenfoot.getRandomNumber(600));  // reposiciona na borda direita com uma posição Y aleatória
    }
    
    if(getY() >= getWorld().getWidth() -1) {
        getWorld().removeObject(this);
    }
    }
    
}